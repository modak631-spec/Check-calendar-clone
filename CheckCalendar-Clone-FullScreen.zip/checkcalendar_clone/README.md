# Check Calendar Clone
Fresh Android project based on the reference Check Calendar interaction model.
