package com.checkcalendar.clone;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.*;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int BLUE=Color.rgb(26,115,232), GREEN=Color.rgb(76,175,80), LIGHT_BG=Color.WHITE, DARK_BG=Color.BLACK;
    LinearLayout root, content, tabBar, bottomBar; boolean dark=false, sunday=true, tabsBottom=false; int currentMonth;
    SharedPreferences prefs; ArrayList<CalTab> tabs=new ArrayList<>(); int selectedTab=0; int checksPerDay=1; String icon="";
    Calendar month=Calendar.getInstance();
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} 
    TextView tv(String text,float sp){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(dark?Color.WHITE:Color.rgb(50,50,50)); v.setGravity(Gravity.CENTER_VERTICAL); return v; }
    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); return g; }
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setNavigationBarColor(Color.BLACK); prefs=getSharedPreferences("cc",0); load(); loadData(); month.set(Calendar.DAY_OF_MONTH,1); currentMonth=month.get(Calendar.MONTH); build();}
    void load(){ dark=prefs.getBoolean("dark",false); sunday=prefs.getBoolean("sunday",true); tabsBottom=prefs.getBoolean("tabsBottom",false); checksPerDay=prefs.getInt("checks",1); int n=prefs.getInt("tabCount",1); for(int i=0;i<n;i++) tabs.add(new CalTab(prefs.getString("tab"+i,"New calendar"+(i==0?"":" "+(i+1))))); selectedTab=Math.min(prefs.getInt("selected",0),Math.max(0,n-1)); icon=prefs.getString("icon"," "); }
    void save(){SharedPreferences.Editor e=prefs.edit().putBoolean("dark",dark).putBoolean("sunday",sunday).putBoolean("tabsBottom",tabsBottom).putInt("checks",checksPerDay).putInt("tabCount",tabs.size()).putInt("selected",selectedTab).putString("icon",icon); for(int i=0;i<tabs.size();i++)e.putString("tab"+i,tabs.get(i).title); e.apply();}
    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(dark?DARK_BG:LIGHT_BG);
        setContentView(root); buildHome();
    }
    void buildHome(){ root.removeAllViews(); buildTopTabs();
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setLayoutParams(new LinearLayout.LayoutParams(-1,0,1)); content.setPadding(0,dp(8),0,0); content.setBackgroundColor(dark?Color.BLACK:Color.WHITE); root.addView(content);
        buildCalendar(); buildBottomNav();
    }
    void buildTopTabs(){
        tabBar=new LinearLayout(this); tabBar.setOrientation(LinearLayout.HORIZONTAL); tabBar.setGravity(Gravity.CENTER_VERTICAL); tabBar.setPadding(dp(4),0,dp(4),0); tabBar.setBackgroundColor(dark?Color.rgb(37,37,38):Color.rgb(238,238,238));
        HorizontalScrollView hsv=new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false); hsv.setFillViewport(false); hsv.addView(tabBar); hsv.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(62))); root.addView(hsv);
        renderTabs();
    }
    void renderTabs(){tabBar.removeAllViews(); for(int i=0;i<tabs.size();i++){ final int idx=i; TextView t=tv((tabs.get(i).title==null||tabs.get(i).title.isEmpty())?"New calendar":tabs.get(i).title,16); t.setGravity(Gravity.CENTER); t.setPadding(dp(16),0,dp(16),0); t.setMinWidth(dp(110)); t.setSingleLine(true); t.setTypeface(null, idx==selectedTab?Typeface.BOLD:Typeface.NORMAL); t.setBackground(bg(idx==selectedTab?(dark?Color.rgb(55,55,56):Color.WHITE):Color.TRANSPARENT,8)); t.setOnClickListener(v->{selectedTab=idx; save(); buildHome();}); t.setOnLongClickListener(v->{tabMenu(idx); return true;}); tabBar.addView(t,new LinearLayout.LayoutParams(-2,dp(50)));}
        TextView plus=tv("+",30); plus.setGravity(Gravity.CENTER); plus.setPadding(dp(8),0,dp(8),0); plus.setOnClickListener(v->addTab()); tabBar.addView(plus,new LinearLayout.LayoutParams(dp(52),dp(62))); }
    void addTab(){if(tabs.size()>=3){new AlertDialog.Builder(this).setMessage("Free version allows up to 3 calendars.").setPositiveButton("OK",null).show();return;} tabs.add(new CalTab("New calendar")); selectedTab=tabs.size()-1; save(); buildHome();}
    void tabMenu(int idx){ final String[] items={"Rename the calendar","Delete this calendar","Change the icon"}; new AlertDialog.Builder(this).setTitle(tabs.get(idx).title).setItems(items,(d,w)->{if(w==0)renameTab(idx); else if(w==1)deleteTab(idx); else changeIcon(idx);}).show(); }
    void renameTab(int idx){ EditText e=new EditText(this); e.setSingleLine(); e.setText(tabs.get(idx).title); new AlertDialog.Builder(this).setTitle("Rename the calendar").setView(e).setNegativeButton("Cancel",null).setPositiveButton("OK",(d,w)->{tabs.get(idx).title=e.getText().toString();save();renderTabs();}).show(); }
    void deleteTab(int idx){ new AlertDialog.Builder(this).setTitle("Do you want to delete the calendar?").setMessage("The data in this calendar will be permanently deleted and cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("OK",(d,w)->{tabs.remove(idx); if(tabs.isEmpty())tabs.add(new CalTab("New calendar")); selectedTab=Math.min(selectedTab,tabs.size()-1); save();buildHome();}).show(); }
    void changeIcon(int idx){ final String[] a={"","✓","★","●","♥","🔥","💪","📚","🏃","⭐"}; new AlertDialog.Builder(this).setTitle("Change the icon").setItems(a,(d,w)->{tabs.get(idx).icon=a[w]; save(); buildHome();}).show(); }
    void buildCalendar(){
        LinearLayout header=new LinearLayout(this); header.setOrientation(LinearLayout.HORIZONTAL); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(12),0,dp(4),0); content.addView(header,new LinearLayout.LayoutParams(-1,dp(50)));
        TextView title=tv("",18); title.setTypeface(null,Typeface.NORMAL); header.addView(title,new LinearLayout.LayoutParams(0,-1,1));
        TextView total=tv("",10); total.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); header.addView(total,new LinearLayout.LayoutParams(dp(150),-1));
        TextView cal=tv("▣",27); cal.setGravity(Gravity.CENTER); cal.setOnClickListener(v->calendarOptions()); header.addView(cal,new LinearLayout.LayoutParams(dp(45),dp(45)));
        updateHeader(title,total);
        buildMonthGrid();
    }
    void updateHeader(TextView title,TextView total){ Calendar c=(Calendar)month.clone(); SimpleDateFormat f=new SimpleDateFormat("MMMM yyyy",Locale.US); title.setText(f.format(c.getTime())); int n=totalCount(c.get(Calendar.YEAR),c.get(Calendar.MONTH)); String mode=prefs.getString("display","total"); total.setText(("month".equals(mode)?"Month":"Total")+"\n"+n+" Times"); }
    int totalCount(int y,int m){int sum=0; String prefix=""+y+String.format(Locale.US,"%02d",m+1); for(String k:tabs.get(selectedTab).checks.keySet()) if(k.startsWith(prefix))sum+=tabs.get(selectedTab).checks.get(k); return sum;}
    void buildMonthGrid(){ final Calendar c=(Calendar)month.clone(); LinearLayout holder=new LinearLayout(this); holder.setOrientation(LinearLayout.VERTICAL); holder.setLayoutParams(new LinearLayout.LayoutParams(-1,0,1));
        String[] wd=new DateFormatSymbols(Locale.US).getShortWeekdays(); LinearLayout days=new LinearLayout(this); days.setGravity(Gravity.CENTER); for(int i=0;i<7;i++){int pos=sunday?i:(i+1)%7; TextView d=tv(wd[pos+1],13); d.setGravity(Gravity.CENTER); days.addView(d,new LinearLayout.LayoutParams(0,dp(40),1));} holder.addView(days);
        GridLayout grid=new GridLayout(this); grid.setColumnCount(7); grid.setRowCount(6); grid.setUseDefaultMargins(false); grid.setBackgroundColor(dark?Color.rgb(34,34,34):Color.rgb(238,238,238)); holder.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        Calendar first=(Calendar)c.clone(); first.set(Calendar.DAY_OF_MONTH,1); int dow=first.get(Calendar.DAY_OF_WEEK)-1; int start=sunday?dow:(dow+6)%7; int max=c.getActualMaximum(Calendar.DAY_OF_MONTH); Calendar prev=(Calendar)c.clone(); prev.add(Calendar.MONTH,-1); int pmax=prev.getActualMaximum(Calendar.DAY_OF_MONTH);
        for(int cell=0;cell<42;cell++){ int day=cell-start+1; Calendar date=(Calendar)c.clone(); if(day<1){date.set(Calendar.MONTH,c.get(Calendar.MONTH)-1); date.set(Calendar.DAY_OF_MONTH,pmax+day);} else if(day>max){date.set(Calendar.MONTH,c.get(Calendar.MONTH)+1); date.set(Calendar.DAY_OF_MONTH,day-max);} else date.set(Calendar.DAY_OF_MONTH,day); addDay(grid,date,day>=1&&day<=max); }
        content.addView(holder); holder.setOnTouchListener(new View.OnTouchListener(){float downX; public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==0){downX=e.getX();return true;} if(e.getAction()==1){float dx=e.getX()-downX;if(Math.abs(dx)>dp(60)){month.add(Calendar.MONTH,dx<0?1:-1); month.set(Calendar.DAY_OF_MONTH,1); buildHome();}return true;}return true;}});
    }
    void addDay(GridLayout grid,Calendar date,boolean current){ final Calendar d=(Calendar)date.clone(); String key=key(d); int count=tabs.get(selectedTab).checks.containsKey(key)?tabs.get(selectedTab).checks.get(key):0;
        LinearLayout cell=new LinearLayout(this); cell.setOrientation(LinearLayout.VERTICAL); cell.setGravity(Gravity.CENTER); cell.setPadding(0,dp(2),0,0); cell.setAlpha(current?1f:.5f); cell.setBackgroundColor(dark?Color.rgb(34,34,34):Color.WHITE);
        TextView day=tv(""+d.get(Calendar.DAY_OF_MONTH),12); day.setGravity(Gravity.CENTER); if(isToday(d)){day.setTextColor(Color.WHITE); day.setBackground(bg(BLUE,24));} cell.addView(day,new LinearLayout.LayoutParams(dp(24),dp(24)));
        TextView mark=tv("",12); mark.setGravity(Gravity.CENTER); String ic=tabs.get(selectedTab).icon; if(count>0){mark.setText(ic==null||ic.isEmpty()?"✓":ic); mark.setTextColor(GREEN); mark.setTextSize(28); if(count>=2){mark.setText(mark.getText()+"×"+count); mark.setTextSize(20);}} cell.addView(mark,new LinearLayout.LayoutParams(-1,0,1));
        cell.setOnClickListener(v->{int old=tabs.get(selectedTab).checks.containsKey(key(d))?tabs.get(selectedTab).checks.get(key(d)):0; int next=(old+1)%(checksPerDay+1); if(next==0)tabs.get(selectedTab).checks.remove(key(d)); else tabs.get(selectedTab).checks.put(key(d),next); saveData(); buildHome();});
        GridLayout.LayoutParams lp=new GridLayout.LayoutParams(); lp.width=0; lp.height=0; lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); lp.rowSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); grid.addView(cell,lp);
    }
    boolean isToday(Calendar d){Calendar n=Calendar.getInstance(); return n.get(Calendar.YEAR)==d.get(Calendar.YEAR)&&n.get(Calendar.DAY_OF_YEAR)==d.get(Calendar.DAY_OF_YEAR);}
    String key(Calendar d){return String.format(Locale.US,"%04d%02d%02d",d.get(Calendar.YEAR),d.get(Calendar.MONTH)+1,d.get(Calendar.DAY_OF_MONTH));}
    void saveData(){save(); StringBuilder b=new StringBuilder(); for(int i=0;i<tabs.size();i++){for(Map.Entry<String,Integer> e:tabs.get(i).checks.entrySet()) b.append(i).append('|').append(e.getKey()).append('|').append(e.getValue()).append(';');} prefs.edit().putString("data",b.toString()).apply();}
    void loadData(){String s=prefs.getString("data",""); if(s.isEmpty())return; for(String q:s.split(";")){String[] a=q.split("\\|"); if(a.length==3)try{int i=Integer.parseInt(a[0]); if(i<tabs.size())tabs.get(i).checks.put(a[1],Integer.parseInt(a[2]));}catch(Exception ignored){}}}
    void calendarOptions(){ String[] items={"Rename the calendar","Delete this calendar","Number of checks per day","Total / Month","Change the icon","Initialize the data"}; new AlertDialog.Builder(this).setTitle(tabs.get(selectedTab).title).setItems(items,(d,w)->{switch(w){case 0:renameTab(selectedTab);break;case 1:deleteTab(selectedTab);break;case 2:chooseChecks();break;case 3:chooseDisplay();break;case 4:changeIcon(selectedTab);break;case 5:clearData();}}).show(); }
    void chooseChecks(){ final String[] a=new String[48]; for(int i=0;i<48;i++)a[i]=""+(i+1); new AlertDialog.Builder(this).setTitle("Number of checks per day").setSingleChoiceItems(a,checksPerDay-1,(d,w)->{checksPerDay=w+1;save();d.dismiss();buildHome();}).show(); }
    void chooseDisplay(){String[] a={"Total","Month"}; String cur=prefs.getString("display","total"); new AlertDialog.Builder(this).setTitle("Total number of checks").setSingleChoiceItems(a,"month".equals(cur)?1:0,(d,w)->{prefs.edit().putString("display",w==1?"month":"total").apply();d.dismiss();buildHome();}).show();}
    void clearData(){new AlertDialog.Builder(this).setTitle("Do you want to initialize the data?").setMessage("The original data will be permanently deleted. It is irreversible.").setNegativeButton("Cancel",null).setPositiveButton("OK",(d,w)->{for(CalTab t:tabs)t.checks.clear();saveData();buildHome();}).show();}
    void buildBottomNav(){ bottomBar=new LinearLayout(this); bottomBar.setOrientation(LinearLayout.HORIZONTAL); bottomBar.setBackgroundColor(dark?Color.rgb(25,25,25):Color.rgb(250,250,250)); TextView h=tv("⌂\nHome",12), s=tv("⚙\nPreferences",12); h.setGravity(Gravity.CENTER);s.setGravity(Gravity.CENTER); h.setTextColor(BLUE); h.setOnClickListener(v->buildHome()); s.setOnClickListener(v->buildPreferences()); bottomBar.addView(h,new LinearLayout.LayoutParams(0,dp(60),1)); bottomBar.addView(s,new LinearLayout.LayoutParams(0,dp(60),1)); root.addView(bottomBar); }
    void buildPreferences(){root.removeAllViews(); LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(dark?DARK_BG:LIGHT_BG); root.addView(page,new LinearLayout.LayoutParams(-1,0,1)); TextView title=tv("Preferences",20);title.setTypeface(null,Typeface.BOLD);title.setPadding(dp(18),dp(18),dp(18),dp(12));page.addView(title,new LinearLayout.LayoutParams(-1,dp(64))); addPref(page,"★   Check Calendar Premium","One-time purchase • unlimited tabs"); addSwitch(page,"Start the calendar on Sunday",sunday,v->{sunday=v;save();}); addSwitch(page,"Place tabs on bottom",tabsBottom,v->{tabsBottom=v;save();}); addPref(page,"Sort Tabs","Press and hold a tab to rearrange it left or right."); addSwitch(page,"Switch to dark mode",dark,v->{dark=v;save();applyTheme();}); TextView init=tv("  Initialize the data",16);init.setPadding(dp(18),dp(20),dp(18),dp(20));init.setOnClickListener(v->clearData());page.addView(init); bottomBar=new LinearLayout(this);bottomBar.setOrientation(LinearLayout.HORIZONTAL);bottomBar.setBackgroundColor(dark?Color.rgb(25,25,25):Color.rgb(250,250,250));TextView h=tv("⌂\nHome",12),s=tv("⚙\nPreferences",12);h.setGravity(Gravity.CENTER);s.setGravity(Gravity.CENTER);s.setTextColor(BLUE);h.setOnClickListener(v->buildHome());bottomBar.addView(h,new LinearLayout.LayoutParams(0,dp(60),1));bottomBar.addView(s,new LinearLayout.LayoutParams(0,dp(60),1));root.addView(bottomBar); }
    void addPref(LinearLayout p,String a,String b){TextView x=tv(a+"\n"+b,16);x.setPadding(dp(18),dp(14),dp(18),dp(14));p.addView(x,new LinearLayout.LayoutParams(-1,dp(72)));}
    void addSwitch(LinearLayout p,String label,boolean value,final SwitchCallback cb){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(18),0,dp(10),0);TextView t=tv(label,16);row.addView(t,new LinearLayout.LayoutParams(0,dp(58),1));Switch sw=new Switch(this);sw.setChecked(value);sw.setOnCheckedChangeListener((b,c)->cb.go(c));row.addView(sw);p.addView(row,new LinearLayout.LayoutParams(-1,dp(58))); View line=new View(this);line.setBackgroundColor(dark?Color.rgb(45,45,45):Color.rgb(230,230,230));p.addView(line,new LinearLayout.LayoutParams(-1,1));}
    interface SwitchCallback{void go(boolean v);} 
    void applyTheme(){getWindow().setStatusBarColor(dark?Color.BLACK:Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);buildHome();}
    static class CalTab{String title,icon="";HashMap<String,Integer> checks=new HashMap<>();CalTab(String t){title=t;}}
}
